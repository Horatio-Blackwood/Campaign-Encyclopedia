Thanks for using Campaign Encyclopedia.
I hope you find it genuinely useful.  This
release was created on March 19, 2015.

- Adam Anderson