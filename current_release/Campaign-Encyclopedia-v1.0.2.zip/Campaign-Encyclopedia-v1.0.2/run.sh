java -cp ":./lib/*" campaignencyclopedia.CampaignEncyclopedia
