java -cp ":./lib/*" campaignencyclopedia.data.persistence.SaveFileUpgrader
